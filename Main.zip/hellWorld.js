Console.log("passionProject");

document.write("EnvironmentProject"+<br>);

var passion = 2021;
var project = 7;

var environment = passion * project;

document.write(environment);	// induk passion
