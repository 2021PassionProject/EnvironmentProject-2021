# EnvironmentProject-2021
## EnvironmentProject-7

이 README.md에다가 잠시 git을 배우기 위해 몇 가지 테스트 내용을 추가했습니다.

소스코드 블록은 다음과 같이 작성할 수 있습니다.

```java
public class Main{
  public static main void(String []args) {
    System.out.println("passion");
  }
}

```

링크는 다음과 같이 작성할 수 있습니다.

[다들 이거 보고 git 배우시면 됩니다](https://www.youtube.com/watch?v=MFJIOqxK6k8&list=PLRx0vPvlEmdD5FLIdwTM4mKBgyjv4no81&index=11)

순서 없는 목록은 다음과 같이 작성할 수 있습니다.

* git tutorial
  * git Clone
  * git Pull
  * git Commit
    * git Commit 1)
    * git Commit 2)

인용 구문은 다음과 같이 작성할 수 있습니다.
> '패션 화이팅' - 한정수 - 

테이블은 다음과 같이 작성할 수 있습니다.

Name|Java|PHP|Javascript|Python|
----|----|---|-------|-----|
한정수|99점|95점|100점|95점|

강조는 다음과 같이 할 수 있습니다.

**이거 README.me파일** 있잖아요.  
~~수정하셔도 돼요.~~

